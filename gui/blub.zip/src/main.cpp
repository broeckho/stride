#include <QDebug>

int main() {
    qDebug() << QT_VERSION_STR;
    return 0;
}